package com.spring.secu02.user;


import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("userDao")
public class UserDao extends EgovAbstractDAO {
//	@Autowired
//	private SqlSession sqlSession;
	
//	public void insertUser(UserVO userVO) throws DataAccessException{
//		sqlSession.insert("mapper.user.insertUser", userVO);
//	}



	public String InsertUser(UserVO vo) {
		// TODO Auto-generated method stub
		return (String)insert("userDao.InsertUser",vo);
	}

}