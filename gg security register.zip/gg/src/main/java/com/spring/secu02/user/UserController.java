package com.spring.secu02.user;

import java.util.Locale;

import javax.annotation.Resource;
import javax.inject.Inject;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;




@Controller
public class UserController {
////	@Autowired
////    PasswordEncoder passwordEncoder;
//    @Autowired(required = false)
//   // @Autowired
//    UserDao userDao;
//    
////    @Resource(name="userDao")
////    private UserDao userDao;
//
//
//	@RequestMapping(value = "/user/userForm.do", method = RequestMethod.GET)
//	public String userForm(Locale locale, Model model) {
//		return "user/userForm";
//	}
//
//	@RequestMapping(value = "/user/addUser.do", method = RequestMethod.POST)
//	public String addUser(@ModelAttribute UserVO userVO ) {
////		String encPassword = passwordEncoder.encode(userVO.getPassword());
//		System.out.println("adduser출력"+userVO.getUsername());
//		System.out.println("아이디출력"+userVO.getPassword());
//		System.out.println("enabled출력"+userVO.getEnabled());
////        userVO.setPassword(encPassword);
//		userDao.insertUser(userVO);
//		return "home";
//	}
}



