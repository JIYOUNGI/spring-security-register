package egovframework.example.sample.service.impl;


import org.springframework.stereotype.Repository;

import egovframework.example.sample.service.UserVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("UserDao")
public class UserDao extends EgovAbstractDAO {
//	@Autowired
//	private SqlSession sqlSession;
	
//	public void insertUser(UserVO userVO) throws DataAccessException{
//		sqlSession.insert("mapper.user.insertUser", userVO);
//	}



	public String InsertUser(UserVO vo) {
		// TODO Auto-generated method stub
		return (String)insert("UserDao.InsertUser",vo);
	}

}