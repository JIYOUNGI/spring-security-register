package egovframework.example.sample.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.example.sample.service.UserVO;
import egovframework.example.sample.service.userService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("userService")
public class userServiceImpl extends EgovAbstractServiceImpl implements userService {
	
	@Resource(name = "UserDao")
	private UserDao UserDao;

	@Override
	public String InsertUser(UserVO vo) throws Exception {
		// TODO Auto-generated method stub
		return UserDao.InsertUser(vo);
	}

}
