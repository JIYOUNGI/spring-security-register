package egovframework.example.sample.service;



public interface userService {
	
	public String InsertUser(UserVO vo) throws Exception;

}
